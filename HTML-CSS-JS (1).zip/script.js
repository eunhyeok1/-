// 번호 추첨 함수
function generateNumbers() {
    // 기존에 추첨된 번호가 있다면 초기화
    document.getElementById('numbers').innerHTML = '';

    // 1부터 45까지 번호 배열 생성
    let numbers = Array.from(Array(45), (_, index) => index + 1);

    // 번호 섞기 (Fisher-Yates 알고리즘 활용)
    for (let i = numbers.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [numbers[i], numbers[j]] = [numbers[j], numbers[i]];
    }

    // 앞에서부터 6개의 번호 추출하여 정렬
    let selectedNumbers = numbers.slice(0, 6).sort((a, b) => a - b);

    // SweetAlert2 팝업으로 결과를 표시
    Swal.fire({
        title: "추첨 결과",
        html: `<div class="text-4xl font-bold">${selectedNumbers.join(', ')}</div>`,
        icon: 'success',
        confirmButtonText: '확인',
        confirmButtonColor: '#4CAF50',
        customClass: {
            title: 'text-2xl',  // 제목 크기 조정
            htmlContainer: 'text-center',  // 내용 중앙 정렬
        }
    });
}
